
#include"minString.hxx"
#include"minArray.hxx"

int BurrowsWheelerTrans( const String & input, String & output, Array<int> & idbuf );
int ReverseBurrowsWheelerTrans( const String & input, String & output, Array<int> & idbuf );
